package Map;
/**
 * Class that encapsulates a move
 * @author Radu
 *
 */
public class Move {
	

	private char direction;
	
	public Move (char direction) {
		this.direction = direction;
	}
	
	
	public char getDirection () {
		return direction;
	}
	
	
}

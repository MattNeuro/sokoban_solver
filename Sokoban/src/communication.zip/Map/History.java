package Map;

import java.util.LinkedList;

public class History<Node> extends LinkedList {
	
	
	public History (Map map) {
		
	}

}

package Map;

public class Node {

}

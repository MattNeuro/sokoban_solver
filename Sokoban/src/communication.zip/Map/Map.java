package Map;


import java.util.LinkedList;
import java.util.Vector;
/**
 * Class that contains the map and all its features
 * @author Radu
 *
 */
public class Map {
	
	static final int BOX=1; // there is a box on the square
	static final int WALL=2; // there is a wall on the square
	static final int EMPTY=3; //there is nothing on the square
	static final int GOAL=4; //there is a goal on the square
	static final int BOXGOAL=5; //there is a box on a goal square
	static final int PLAYER=6; //the player is on the square
	static final int PLAYERGOAL=7; // the player is on a goal square
	static final int DEADLOCK=8; // the square is a deadlock
	static final int PLAYERDEADLOCK=9; // the player is on a deadlock
    int coord[][]; // matrix representation of the map
    int maxRow; // number of rows 
    int maxCol; // number of columns
    public Vector<Box> boxes=new Vector<Box>(); //vector that contains the boxes
    
    
    
    /**
     * returns true if the map in question is solved
     * @return 
     */
    public boolean isSolved() {
    	int nrBoxes=boxes.size();
    	for (int i=0;i<maxRow;i++)
    		for (int j=0;j<maxCol;j++) {
    			if (coord[i][j]==BOXGOAL)
    				nrBoxes--;
    		}
    			
    	if (nrBoxes==0)
    		return true;
    	else
    		return false;
    }
    
    /*
    @Override public boolean equals (Object object) {
    	Map map = (Map) object;
    	//eturn map.coord.equals(this.coord);
    	return false;
    }*/
    
    
    
    /**
	 * Print the current map contents
	 * @param map: matrix representation of the map
	 */
	public void printMap() {
		for (int i=0;i<coord.length;i++) { 
			for (int j=0;j<coord[0].length;j++)
				switch (coord[i][j]) {
					case WALL:
						System.out.print("#");
						break;
					case PLAYER:
						System.out.print("@");
						break;
					case BOX:
						System.out.print("$");
						break;
					case GOAL:
						System.out.print(".");
						break;
					case BOXGOAL:
						System.out.print("*");
						break;
					case PLAYERGOAL:
						System.out.print("+");
						break;
					case EMPTY:
						System.out.print(" ");
						break;
					case DEADLOCK:
						System.out.print("d");
						break;
					case PLAYERDEADLOCK:
						System.out.print("D");
						break;
				}
			System.out.println();
		}
		
	
		
	}
    
    /** 
	 * Parses a map string creating a matrix representing the map
	 * @param inputString: the string received from the server
	 * containing the positions of the walls,boxes,player, etc.
	 */
	public Map(String inputString) {
		 	int col = 0;
	        int row = 1;
	        int maxRow = 0;
	        int maxCol = 0;

	        for (int i=0;i<inputString.length();i++) {
	            if (inputString.charAt(i) == '\n') {
	                if (col != 0)
	                    row++;
	                if (col > maxCol)
	                    maxCol = col;
	                	this.maxCol=col;
	                col = 0;
	            } 
	            else {
	                col++;
	            }
	        }
	        maxRow = row;
	        this.maxRow=row;
	       
  
	      
	        coord=new int[maxRow][maxCol];

	        col = 0;
	        row = 0;

	        for (int i=0;i<inputString.length();i++) {
	        	switch(inputString.charAt(i)) {
	                case '*':
	                    coord[row][col] = BOXGOAL;
	                    boxes.add(new Box(row,col));
	                    break;
	                case '.':
	                    coord[row][col] = GOAL;
	                    break;
	                case '#':
	                    coord[row][col] = WALL;
	                    break;
	                case '$':
	                    coord[row][col] = BOX;
	                    boxes.add(new Box(row,col));
	                    break;
	                case '+':
	                    coord[row][col] = PLAYERGOAL;
	                    break;
	                case '@':
	                    coord[row][col] = PLAYER;
	                    break;
	                case ' ':
	                    coord[row][col] = EMPTY;
	                    break;
	                case '\n':
	                    row++;
	                    col = 0;
	                    break;
	            }

	            if (inputString.charAt(i)!= '\n')
	                col++;
	        }
	        // bound the map
	        for (int x = 0; x < maxCol; x++)
	            coord[0][x] = coord[maxRow-1][x] = WALL;
	        for (int y = 0; y < maxRow; y++)
	            coord[y][0] = coord[y][maxCol-1] = WALL;
	        
	   
	}
    
	
	/**
	 * 	Copy-constructor. Create a new Map object from an old one.
	 * 
	 * 	@param map
	 */
    public Map (Map source) {
        this.coord 	= source.coord;  // matrix representation of the map
        this.maxRow = source.maxRow; // number of rows 
        this.maxCol = source.maxCol; // number of columns
        this.boxes 	= source.boxes;  //vector that contains the boxes
	}



	/**
     * Add initial deadlocks to a map (corners and lines along the walls connecting the corners)
     * @param map: the matrix representation of the map
     */
    public void addDeadlocks() {
    	//find corners first
    	for (int i=0;i<coord.length;i++)
    		for (int j=0;j<coord[0].length;j++) {
    			if (coord[i][j]==EMPTY && (coord[i+1][j]==WALL && coord[i+1][j+1]==WALL && coord[i][j+1]==WALL)) coord[i][j]=DEADLOCK;
    			if (coord[i][j]==EMPTY && (coord[i-1][j]==WALL && coord[i-1][j+1]==WALL && coord[i][j+1]==WALL)) coord[i][j]=DEADLOCK;
    			if (coord[i][j]==EMPTY && (coord[i-1][j]==WALL && coord[i-1][j-1]==WALL && coord[i][j-1]==WALL)) coord[i][j]=DEADLOCK;
    			if (coord[i][j]==EMPTY && (coord[i][j-1]==WALL && coord[i+1][j-1]==WALL && coord[i+1][j]==WALL)) coord[i][j]=DEADLOCK;
    			
    			if (coord[i][j]==PLAYER && (coord[i+1][j]==WALL && coord[i+1][j+1]==WALL && coord[i][j+1]==WALL)) coord[i][j]=PLAYERDEADLOCK;
    			if (coord[i][j]==PLAYER && (coord[i-1][j]==WALL && coord[i-1][j+1]==WALL && coord[i][j+1]==WALL)) coord[i][j]=PLAYERDEADLOCK;
    			if (coord[i][j]==PLAYER && (coord[i-1][j]==WALL && coord[i-1][j-1]==WALL && coord[i][j-1]==WALL)) coord[i][j]=PLAYERDEADLOCK;
    			if (coord[i][j]==PLAYER && (coord[i][j-1]==WALL && coord[i+1][j-1]==WALL && coord[i+1][j]==WALL)) coord[i][j]=PLAYERDEADLOCK;
    			
    		}
    	
    	
    }
    
    
    /**
     * returns true if there is a player at row x and column y
     * @param x: the row in question
     * @param y: the column in question
     * @return
     */
    public boolean isPlayer(int x, int y) {
		if (coord[x][y]==PLAYER || coord[x][y]==PLAYERGOAL || coord[x][y]==PLAYERDEADLOCK)
			return true;
		else 
			return false;
	}
    
    /**
     * returns true if the map is empty at row x and column y
     * @param x: the row in question
     * @param y: the column in question
     * @return
     */
	public boolean isEmpty (int x, int y) {
		if (coord[x][y]==EMPTY)
			return true;
		else 
			return false;
	}
	
	
	/**
	 * returns true if there is a wall at row x and column y
	 * @param x: the row in question
	 * @param y: the column in question
	 * @return
	 */
	public boolean isWall (int x,int y) {
		if (coord[x][y]==WALL)
			return true;
		else 
			return false;
	}
	
	
	
	/**
	 * returns true if there is a goal at position x,y
	 * @param x: row
	 * @param y: column
	 * @return
	 */
	public boolean isGoal(int x,int y) {
		if (coord[x][y]==GOAL || coord[x][y]==PLAYERGOAL || coord[x][y]==BOXGOAL)
			return true;
		else 
			return false;
	}

	
	
	/**
	 * returns true if there is a deadlock at position x,y
	 * @param x: row
	 * @param y: column
	 * @return
	 */
	public boolean isDeadlock(int x,int y) {
		if (coord[x][y]==DEADLOCK || coord[x][y]==PLAYERDEADLOCK)
			return true;
		else
			return false;
	}
	
	
	
	
	/** 
	 * returns the player position as a Point
	 * @return
	 */
	public Point getPlayer () {
		Point p=null;
		outer:
		for (int x=0;x<maxRow;x++)
			for (int y=0;y<maxCol;y++)
				if (coord[x][y]==PLAYER || coord[x][y]==PLAYERDEADLOCK || coord[x][y]==PLAYERGOAL) {
					p=new Point(x,y);
					break outer;
					
				}
		return p;
					
	}
	
	
	/**
	 * returns true if there is a box at position x,y
	 * @param x: row
	 * @param y: column
	 * @return
	 */
	public boolean isBox(int x,int y){
		if (coord[x][y]==BOX || coord[x][y]==BOXGOAL)
			return true;
		else
			return false;
			
		}
	
	
	/**
	 * returns the index of a box in the boxes Vector of the box at position x,y
	 * @param x: row
	 * @param y: column
	 * @return
	 */
	public int boxIndex (int x, int y) {
		for (int i = 0; i < boxes.size(); i++) {
			Box box = boxes.elementAt(i);
			Point location = box.getLocation();
			
			if (location.x == x && location.y == y) 
				return i; // returns the box indice in the boxes vector
		}
		return -1; // there isn't a box at x,y
	}
	
	
	/**
	 * determines the possible moves in a particular board
	 * @return
	 */
	public LinkedList<Move> findMoves () {
		LinkedList<Move> moves = new LinkedList<Move>();
		for (int i=0;i<maxRow;i++)
			for (int j=0;j<maxCol;j++) {
				if (isPlayer(i,j)) {
					
					if (isEmpty(i+1,j) || (isBox(i+1,j) && (isEmpty(i+2,j) || isGoal(i+2,j))) || isGoal(i+1,j) || isDeadlock(i+1,j)) moves.add(new Move('D')); // if the square below is empty, or it has a box that has somewhere to go, or is a goal, you can go down
					if (isEmpty(i-1,j) || (isBox(i-1,j) && (isEmpty(i-2,j) || isGoal(i-2,j))) || isGoal(i-1,j) || isDeadlock(i-1,j)) moves.add(new Move('U'));
					if (isEmpty(i,j+1) || (isBox(i,j+1) && (isEmpty(i,j+2) || isGoal(i,j+2))) || isGoal(i,j+1) || isDeadlock(i,j+1)) moves.add(new Move('R'));
					if (isEmpty(i,j-1) || (isBox(i,j-1) && (isEmpty(i,j-2) || isGoal(i,j-2))) || isGoal(i,j-1) || isDeadlock(i,j-1)) moves.add(new Move('L'));
				}
			}
		return moves;
	}
	
	
	
	/**
	 * Executes a move and returns the resulting map	
	 * @param move: the executed move
	 * @return: resulting map
	 */
	public Map doMove(Move move) {
		Map newMap = new Map(this);
		newMap.performMove(move);
		return newMap;
	}
	

	private void performMove (Move move) {
		int index;
		Point playerPosition=getPlayer();
		int x=playerPosition.x;
		int y=playerPosition.y;
		char direction=move.getDirection();
		
		if (direction=='U') {
			
			index=boxIndex(x-1,y);
			
			if (index<0) { // there is no box above
				if (coord[x-1][y]==EMPTY && coord[x][y]==PLAYERDEADLOCK) {
					coord[x-1][y]=PLAYER;
					coord[x][y]=DEADLOCK;
				}
				if (coord[x-1][y]==EMPTY && coord[x][y]==PLAYER) {
					coord[x-1][y]=PLAYER;
					coord[x][y]=EMPTY;
				}
				if (coord[x-1][y]==DEADLOCK && coord[x][y]==PLAYER) {
					coord[x-1][y]=PLAYERDEADLOCK;
					coord[x][y]=EMPTY;
				}						
				if (coord[x-1][y]==EMPTY && coord[x][y]==PLAYERGOAL) {
					coord[x-1][y]=PLAYER;
					coord[x][y]=GOAL;
				}
				if (coord[x-1][y]==GOAL && coord[x][y]==PLAYERDEADLOCK) {
					coord[x-1][y]=PLAYERGOAL;
					coord[x][y]=DEADLOCK;
				}
				if (coord[x-1][y]==GOAL && coord[x][y]==PLAYER) {
					coord[x-1][y]=PLAYERGOAL;
					coord[x][y]=EMPTY;
				}
				if (coord[x-1][y]==GOAL && coord[x][y]==PLAYERGOAL) {
					coord[x-1][y]=PLAYERGOAL;
					coord[x][y]=GOAL;
				}
			}
			
			else { //there is a box above
				boxes.elementAt(index).boxLocation.x+=-1; // the box moves up one row
			
				if (coord[x-1][y]==BOX) { //not on goal
			
					if (coord[x-2][y]==EMPTY && coord[x][y]==PLAYERDEADLOCK) {
						coord[x-2][y]=BOX;
						coord[x][y]=DEADLOCK;
						coord[x-1][y]=PLAYER;
					}
					if (coord[x-2][y]==EMPTY && coord[x][y]==PLAYER) {
						coord[x-2][y]=BOX;
						coord[x][y]=EMPTY;
						coord[x-1][y]=PLAYER;
					}
					if (coord[x-2][y]==EMPTY && coord[x][y]==PLAYERGOAL) {
						coord[x-2][y]=BOX;
						coord[x][y]=GOAL;
						coord[x-1][y]=PLAYER;
					}
					if (coord[x-2][y]==GOAL && coord[x][y]==PLAYERDEADLOCK) {
						coord[x-2][y]=BOXGOAL;
						coord[x][y]=DEADLOCK;
						coord[x-1][y]=PLAYER;
					}
					if (coord[x-2][y]==GOAL && coord[x][y]==PLAYER) {
						coord[x-2][y]=BOXGOAL;
						coord[x][y]=EMPTY;
						coord[x-1][y]=PLAYER;
					}
					if (coord[x-2][y]==GOAL && coord[x][y]==PLAYERGOAL) {
						coord[x-2][y]=BOXGOAL;
						coord[x][y]=GOAL;
						coord[x-1][y]=PLAYER;
					}
				}
				
				else if (coord[x-1][y]==BOXGOAL) {
					// to be continued, too tired now
				}
					
			}
		}
		// toDo: review everything below this line, make sure I have all possible situations
		
		if (direction=='D') {
			
			index=boxIndex(x+1,y); // returns the index of the box that's below the player
			
			if (index<0) { //there is no box below
				if (coord[x+1][y]==EMPTY && coord[x][y]==PLAYERDEADLOCK) {
					coord[x+1][y]=PLAYER;
					coord[x][y]=DEADLOCK;
				}
				if (coord[x+1][y]==EMPTY && coord[x][y]==PLAYER) {
					coord[x+1][y]=PLAYER;
					coord[x][y]=EMPTY;
				}
				if (coord[x+1][y]==DEADLOCK && coord[x][y]==PLAYER) {
					coord[x+1][y]=PLAYERDEADLOCK;
					coord[x][y]=EMPTY;
				}				
				if (coord[x+1][y]==EMPTY && coord[x][y]==PLAYERGOAL) {
					coord[x+1][y]=PLAYER;
					coord[x][y]=GOAL;
				}
				if (coord[x+1][y]==GOAL && coord[x][y]==PLAYERDEADLOCK) {
					coord[x+1][y]=PLAYERGOAL;
					coord[x][y]=DEADLOCK;
				}
				if (coord[x+1][y]==GOAL && coord[x][y]==PLAYER) {
					coord[x+1][y]=PLAYERGOAL;
					coord[x][y]=EMPTY;
				}
				if (coord[x+1][y]==GOAL && coord[x][y]==PLAYERGOAL) {
					coord[x+1][y]=PLAYERGOAL;
					coord[x][y]=GOAL;
				}
			}
			
			else { //there is a box below
				boxes.elementAt(index).boxLocation.x+=1;
				if (coord[x+2][y]==EMPTY && coord[x][y]==PLAYERDEADLOCK) {
					coord[x+2][y]=BOX;
					coord[x][y]=DEADLOCK;
				}
				if (coord[x+2][y]==EMPTY && coord[x][y]==PLAYER) {
					coord[x+2][y]=BOX;
					coord[x][y]=EMPTY;
				}
				if (coord[x+2][y]==EMPTY && coord[x][y]==PLAYERGOAL) {
					coord[x+2][y]=BOX;
					coord[x][y]=GOAL;
				}
				if (coord[x+2][y]==GOAL && coord[x][y]==PLAYERDEADLOCK) {
					coord[x+2][y]=BOXGOAL;
					coord[x][y]=DEADLOCK;
				}
				if (coord[x+2][y]==GOAL && coord[x][y]==PLAYER) {
					coord[x+2][y]=BOXGOAL;
					coord[x][y]=EMPTY;
				}
				if (coord[x+2][y]==GOAL && coord[x][y]==PLAYERGOAL) {
					coord[x+2][y]=BOXGOAL;
					coord[x][y]=GOAL;
				}
					
			}
		}
		
		
		
		if (direction=='L') {
			
			index=boxIndex(x,y-1);
			
			if (index<0) { //there is no box to the left
				if (coord[x][y-1]==EMPTY && coord[x][y]==PLAYERDEADLOCK) {
					coord[x][y-1]=PLAYER;
					coord[x][y]=DEADLOCK;
				}
				if (coord[x][y-1]==EMPTY && coord[x][y]==PLAYER) {
					coord[x][y-1]=PLAYER;
					coord[x][y]=EMPTY;
				}
				if (coord[x][y-1]==DEADLOCK && coord[x][y]==PLAYER) {
					coord[x][y-1]=PLAYERDEADLOCK;
					coord[x][y]=EMPTY;
				}						
				if (coord[x][y-1]==EMPTY && coord[x][y]==PLAYERGOAL) {
					coord[x][y-1]=PLAYER;
					coord[x][y]=GOAL;
				}
				if (coord[x][y-1]==GOAL && coord[x][y]==PLAYERDEADLOCK) {
					coord[x][y-1]=PLAYERGOAL;
					coord[x][y]=DEADLOCK;
				}
				if (coord[x][y-1]==GOAL && coord[x][y]==PLAYER) {
					coord[x][y-1]=PLAYERGOAL;
					coord[x][y]=EMPTY;
				}
				if (coord[x][y-1]==GOAL && coord[x][y]==PLAYERGOAL) {
					coord[x][y-1]=PLAYERGOAL;
					coord[x][y]=GOAL;
				}
			}
			
			else { // there is a box to the left
				boxes.elementAt(index).boxLocation.y+=-1;
				if (coord[x][y-2]==EMPTY && coord[x][y]==PLAYERDEADLOCK) {
					coord[x][y-2]=BOX;
					coord[x][y]=DEADLOCK;
				}
				if (coord[x][y-2]==EMPTY && coord[x][y]==PLAYER) {
					coord[x][y-2]=BOX;
					coord[x][y]=EMPTY;
				}
				if (coord[x][y-2]==EMPTY && coord[x][y]==PLAYERGOAL) {
					coord[x][y-2]=BOX;
					coord[x][y]=GOAL;
				}
				if (coord[x][y-2]==GOAL && coord[x][y]==PLAYERDEADLOCK) {
					coord[x][y-2]=BOXGOAL;
					coord[x][y]=DEADLOCK;
				}
				if (coord[x][y-2]==GOAL && coord[x][y]==PLAYER) {
					coord[x][y-2]=BOXGOAL;
					coord[x][y]=EMPTY;
				}
				if (coord[x][y-2]==GOAL && coord[x][y]==PLAYERGOAL) {
					coord[x][y-2]=BOXGOAL;
					coord[x][y]=GOAL;
				}
					
			}
		}
		
		
		if (direction=='R') {
			
			index=boxIndex(x+1,y);
			
			if (index<0) { // there is no box to the right
				if (coord[x][y+1]==EMPTY && coord[x][y]==PLAYERDEADLOCK) {
					coord[x][y+1]=PLAYER;
					coord[x][y]=DEADLOCK;
				}
				if (coord[x][y+1]==EMPTY && coord[x][y]==PLAYER) {
					coord[x][y+1]=PLAYER;
					coord[x][y]=EMPTY;
				}
				if (coord[x][y+1]==DEADLOCK && coord[x][y]==PLAYER) {
					coord[x][y+1]=PLAYERDEADLOCK;
					coord[x][y]=EMPTY;
				}						
				if (coord[x][y+1]==GOAL && coord[x][y]==PLAYERDEADLOCK) {
					coord[x][y+1]=PLAYERGOAL;
					coord[x][y]=DEADLOCK;
				}
				if (coord[x][y+1]==GOAL && coord[x][y]==PLAYER) {
					coord[x][y+1]=PLAYERGOAL;
					coord[x][y]=EMPTY;
				}
			}
			
			else { // there is a box to the right
				boxes.elementAt(index).boxLocation.y+=1;
				if (coord[x][y-2]==EMPTY && coord[x][y]==PLAYERDEADLOCK) {
					coord[x][y-2]=BOX;
					coord[x][y]=DEADLOCK;
				}
				if (coord[x][y-2]==EMPTY && coord[x][y]==PLAYER) {
					coord[x][y-2]=BOX;
					coord[x][y]=EMPTY;
				}
				if (coord[x][y-2]==GOAL && coord[x][y]==PLAYERDEADLOCK) {
					coord[x][y-2]=BOXGOAL;
					coord[x][y]=DEADLOCK;
				}
				if (coord[x][y-2]==GOAL && coord[x][y]==PLAYER) {
					coord[x][y-2]=BOXGOAL;
					coord[x][y]=EMPTY;
				}
					
			}
		}
		}
	}


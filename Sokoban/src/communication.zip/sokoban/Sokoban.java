package sokoban;

import Map.MapHandler;
import communication.Client;

/**
 * 	Sokoban Solver class.
 * 
 *	Handles loading a map, starting a sokoban solver
 *	finding a solution through delegated subclasses.
 * 	
 * 	Implemented as a singleton, so other classes can
 *  retrieve a single instance of required resources
 *  shared with the rest of the application.
 * 
 * 	@author Matthijs
 */
final public class Sokoban {
	
	private static 	Sokoban		instance	=	null;
	private        	Client		client		=	null;
	private			MapHandler	mapHandler	=	null;
	private			Solver		solver		=	null;
	
	private			int			mapId		=	0;
	

	// Getters for our instantiated objects:
	public static Client getClient () {
		return Sokoban.instance.client;
	}
	
	
	public static MapHandler getMapHandler () {
		return Sokoban.instance.mapHandler;
	}
	
	
	public static int getMapId () {
		return Sokoban.instance.mapId;
	}
	
	
	/**
	 * 	Public main, this method gets called first and initializes
	 * 	our Sokoban object.
	 * 
	 * 	@param args	Command line arguments. First argument should be
	 * 				the map ID.
	 */
	public static void main(String[] args) {
		try {
			if (args.length < 1)
				throw new Exception("Add a command-line parameter for the map to load.");				
			new Sokoban(args[0]);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
	
	
	/**
	 * 	Sokoban constructor. Create a new Sokoban object, though only if
	 * 	it is not already instantiated.
	 * 
	 * 	@param 	map
	 * 	@throws Exception
	 */
	private Sokoban (String map) throws Exception {
		if (Sokoban.instance != null)
			throw new Exception("Sokoban instance already created.");
		
		Sokoban.instance 	= this;
		mapId 				= Integer.parseInt(map);
		client 				= new Client();
		mapHandler			= new MapHandler();
		solver				= new Solver();
	}
}





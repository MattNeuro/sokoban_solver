package sokoban;

import java.util.LinkedList;

import Map.History;
import Map.Map;
import Map.Move;


/**
 *	Very basic DFS solver for our sokoban puzzle. Will try to move in all
 *	possible directions from each unique point, and keep on moving till we
 *	have solved the puzzle.
 *
 *	 @author Matthijs
 *
 */
public class Solver {

	private LinkedList<Map> 	history;
	private	LinkedList<Move>	solution = null;
	private int					depth	 = 5;
	
	
	/**
	 *  Run the solver. Start with the current map in the MapHandler and
	 *  expand all the moves possible from that map (ie, state).
	 * @throws Exception 
	 */
	public Solver () throws Exception {
		System.out.println("Starting solver.");
		Map map 				= Sokoban.getMapHandler().getMap();
		history 				= new LinkedList<Map>();
		history.add(map);
		LinkedList<Move> past;
		
		while (solution == null && depth < 10) {
			for (Move move : map.findMoves()) {
				past = new LinkedList<Move>();
				past.add(move);
				expandMove(past, map);
			}
			depth = depth * 2;
			history.clear();
			System.out.println("Increased search depth to " + depth + ".");
		}
	}
	
	
	/**
	 * 	Expand a move. After a move has been performed on a map, 
	 * 	we find all the moves we can make then and expand those as well
	 * 	ad infinitum.
	 * 
	 * 	Note that we do not yet have a neat break function: if we reach the
	 * 	goal state, simply throw an exception =D
	 * 
	 * 	@param past		A list of past moves.
	 * 	@param map		The map to perform the new move on.
	 * @throws Exception 
	 */
	private void expandMove (LinkedList<Move> past, Map oldMap) throws Exception {
		Map map = oldMap.doMove(past.peekLast());
		if (map.isSolved())
			solution = past;
		
		System.out.println("---------");
		map.printMap();
		System.out.println("+++++++++");		
		System.out.println();
		
		if (history.contains(map) || past.size() > depth || solution != null) {
			return;
		}
		
		history.add(map);

//		if (history.size() % 100 == 0)
			System.out.println("Analyzed " + history.size() + " different maps at search depth " + depth + ".");
		
		System.out.println("Found " + map.findMoves().size() + " possible moves.");		
			
		LinkedList<Move> current;
		for (Move move : map.findMoves()) {
			System.out.println("Moving : " + move.getDirection());
			current = new LinkedList<Move>(past);
			current.add(move);
			expandMove(current, map);
		}		
	}
}




package communication;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;


import sokoban.Sokoban;

/**
 * 	Client to the Sokoban server. This class establishes a 
 * 	connection to the server, sends which map we want to solve,
 * 	receives the map data, and, when it is solved, sends the
 * 	solution back to the server to be checked.
 * 
 * 	@author Matthijs
 */
public class Client {

	private	BufferedReader	in			=	null;
	private	PrintWriter		out			=	null;
	private	String			map			=	null;

	
	/**
	 * 	Client constructor. Attempts to establish a connection to
	 * 	the server.
	 */
	public Client () throws IOException {
		System.out.println("Starting client listener.");
		connect("localhost");
	}
	
	
	/**
	 * 	Retrieve the string representation of the map that
	 * 	was send to this client by the server. Will throw an
	 * 	exception if no map was loaded.
	 * 
	 * 	Note, due to the crappy way the client was designed, this
	 * 	might contain excess bytes.	
	 * 
	 * 	@return		String containing the map representation.
	 * 	@throws 	Exception
	 */
	public String getMap () throws Exception {
		if (map == null) 
			throw new Exception("Attempt to read board, but board not set.");
		return map;
	}
	
	
	/**
	 * 	Send the solution (for the loaded map?) back to the server. Then, we 
	 * 	wait for the server to evaluate it: this is a string representing 
	 * 	either success or failure.
	 * 
	 * 	@param solution		The (String) representation of the moves that solve
	 * 						the loaded Sokoban puzzle. Should consist of 'UDLR'. 
	 * 	@return
	 * 	@throws Exception
	 */
	public String sendSolution (String solution) throws Exception {
        out.println(solution);
        String result = in.readLine();
        return result;
	}
	
	
	/**
	 * 	Attempt to connect to a server.
	 * 
	 * 	@throws Exception
	 */
	private void connect (String target) throws IOException {
        Socket socket 		= new Socket(target, 5555);
        InputStream inRaw 	= socket.getInputStream();
        in 					= new BufferedReader(new InputStreamReader(inRaw));
        out 				= new PrintWriter(socket.getOutputStream(), true);
        System.out.println("Succesfully connected to " + target);
        
        out.println(Sokoban.getMapId());
        byte[] mapbytes 	= 	new byte[1024];        
        inRaw.read(mapbytes);
        map 				= new String(mapbytes);
        System.out.println("Received board:\r\n " + map);
	}
}





